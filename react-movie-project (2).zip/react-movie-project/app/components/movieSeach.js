import React, (useState) from "react";

export default function SearchMovie(){

    const [query, setQuery] = useState('');
    const [movies, setMovies] =useState([]);
   
   const searachMovie = async ()=> {
       e.preventDefault();
       console.log; {"submitting"};

       const getMovieReviews= {};
      
       try{
           const results = await fetchMovieReviews;
           const data = res.json(results)
           console.log(data.movieReview);
           setMovies(data.movieReviews);
       }catch(err){
           console.error{error};
        }
   }
   
   
   
    return(
        <>
        
           <form className= "form" onSubmit={movieSeach}>
               <label className= "label" htmlForm="query"> Movie Name; </label>
               <inpurt className="input" type=" text" name="query"
                   placeholder="i.e. Lord of the Rings"
                   value={query} onChange = {{e} => setQuery(e.target.value)}

                   />
               < button className= "button" type="submit"{""}Search >
           </form>
           <div className= "movie list">
               (movies.map(movies => movie.title))
           </div>

        </>   
    )
}